
to run:
1) unpack the zip 
2) open cmd and position yourself in the directory of the jar
3) type: java -jar plane_simulator.jar

controls:
QEWSAD - pitch, yaw and roll control
T - enable engines
0-9 - engine power level (should work on both, keyboard and numpad)



it is possible to use additional arguments to see the simulation more under the hood
java -jar plane_simulator.jar [args]

additional args:
-enableHitboxes - make hitboxes visible
-enableFreecam - disable simulation mode and control the camera in a freecam mode; WSADQE for controls, C for culling, V to set the mouse free